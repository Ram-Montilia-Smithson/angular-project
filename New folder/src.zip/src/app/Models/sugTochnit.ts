export class sugTochnit{
    code:number
    name:string 
    condition:boolean

}