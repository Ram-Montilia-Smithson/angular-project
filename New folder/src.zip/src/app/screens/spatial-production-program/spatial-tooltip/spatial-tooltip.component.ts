import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spatial-tooltip',
  templateUrl: './spatial-tooltip.component.html',
  styleUrls: ['./spatial-tooltip.component.scss']
})
export class SpatialTooltipComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
