export class ObjectsFotTableAfterSearch{
    districtName: string;
    foR_Name: string;
    regionName: string;
    trtUnit: string;
    workYear: number;
    wpfsRequestStatus: string; 
    position:number; 
} 