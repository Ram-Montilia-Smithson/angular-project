import { MireDvorim } from "./MireDvorim";

export class Mishkit {
    plant:string
codePlant:number
    name:string;
    phone:string;
    address:string;
    email:string;
    kamut:string;
}