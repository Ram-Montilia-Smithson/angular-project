export class CollectSeedsOrderDetailsAmount0Model{
    constructor(
        public id?:string|number,
        public fruitWeigh?:string|number,
        public seedWeigh?:string|number,
        public bagNumber?:string|number
    ){

    }
}