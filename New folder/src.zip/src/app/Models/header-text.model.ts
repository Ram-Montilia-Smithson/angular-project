export class HeaderTextModel {
  constructor(public key: string, public value: string) {}
}
