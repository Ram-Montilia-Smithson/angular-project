import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collect-seed-main',
  templateUrl: './collect-seed-main.component.html',
  styleUrls: ['./collect-seed-main.component.scss']
})
export class CollectSeedMainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
