import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deforestation',
  templateUrl: './deforestation.component.html',
  styleUrls: ['./deforestation.component.scss']
})
export class DeforestationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
