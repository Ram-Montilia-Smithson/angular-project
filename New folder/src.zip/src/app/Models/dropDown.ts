export class dropDown{
    code:number
    name:string;
}