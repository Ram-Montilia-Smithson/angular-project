export class NewOrderPlantesCompleteExpandingTableModel{
    constructor(
        public id?:number|string,
        public minHatzemach?:string,
        public ashtaol?:string,
        public golani?:string,
        public gilat?:string,
        public total?:string,
    ){}
}