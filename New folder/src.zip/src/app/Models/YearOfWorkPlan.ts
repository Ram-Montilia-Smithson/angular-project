export class YearOfWorkPlan{
    yearOfWorkPlanCode:string
    yearOfWorkPlanName:string
}