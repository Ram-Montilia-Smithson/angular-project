import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-backdrop',
  templateUrl: './login-backdrop.component.html',
  styleUrls: ['./login-backdrop.component.scss']
})
export class LoginBackdropComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
