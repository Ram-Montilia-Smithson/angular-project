export class onatNetia{
    code:number
    name:string
   isShmita:boolean
}