import { BeeGrazing } from "./BeeGrazing";

export class ProductionOfFarmForests extends BeeGrazing{
    name:string;
    phone:string;
    address:string;
    email:string;
    areaOrNursey:string;
}