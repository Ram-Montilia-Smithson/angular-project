export class CollectSeedToDelete{
    globalID:string;
    objectID:number;

}