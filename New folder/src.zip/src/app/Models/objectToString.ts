export class objectToString{
    globalId:string
}