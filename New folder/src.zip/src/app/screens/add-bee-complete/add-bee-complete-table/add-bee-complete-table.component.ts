import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bee-complete-table',
  templateUrl: './add-bee-complete-table.component.html',
  styleUrls: ['./add-bee-complete-table.component.scss']
})
export class AddBeeCompleteTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
