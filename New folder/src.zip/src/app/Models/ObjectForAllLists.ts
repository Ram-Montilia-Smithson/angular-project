
export class ObjectForAllLists<T>{
    name:string
    formControlName:string
    objectOnList:string
    options:T[];
}