export class minHatzemachMishki{
    lakoach:string
    phone:string
   address:string
   email:string
minHatzemach:string
 Ashtaol:number
 Golani:number
 Gilat:number
 total:number
}