import { Component, OnInit } from '@angular/core';
import { AddProductionProcessService } from 'src/app/services/add-production-process.service';

@Component({
  selector: 'app-production-process',
  templateUrl: './production-process.component.html',
  styleUrls: ['./production-process.component.scss']
})
export class ProductionProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
