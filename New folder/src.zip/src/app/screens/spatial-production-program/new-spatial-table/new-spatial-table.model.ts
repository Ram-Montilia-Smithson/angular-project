export class NewSpatialTableModel {
    constructor(
        public id?: string | number,
        public minHatzemach?: string,
        public kamut?: string,
        public ezor?: string,
        public kibul?: string,
        public ribuy?: string,
        public makor?: string,
        public hearot?: string,
        public teurMishpacha?: string,
        public kodMinHatzemach?: number

    ){}
}
