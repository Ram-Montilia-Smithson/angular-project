import { dropDown } from "./dropDown"
import { onatNetia } from "./onatNetia"
import { sugTochnit } from "./sugTochnit"

export class TochniyotYizurList{
      onotNetia :onatNetia[]
      mashtelot:dropDown[]
      sugeyTochnit :sugTochnit[]
      statusim :dropDown[]
      errorMessage :string
      isSuccess :boolean
}