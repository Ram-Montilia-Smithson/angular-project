import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dilol-yarot',
  templateUrl: './dilol-yarot.component.html',
  styleUrls: ['./dilol-yarot.component.scss']
})
export class DilolYarotComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
