export class NewAddBeePlanTableModel{
    constructor(
        public id?:string|number,
        public tzemach?:string,
        public kamut?:string,
        public ashtaol?:string | number,
        public golani?:string | number,
        public gilat?:string | number,
    ){}
}