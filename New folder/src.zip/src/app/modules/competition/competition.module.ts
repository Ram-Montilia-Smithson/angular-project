import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompetitionRoutingModule } from './competition-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CompetitionRoutingModule
  ]
})
export class CompetitionModule { }
