import { ClassField } from "@angular/compiler"


export class AllSearchUnitsForWorkDilution {
    objectID: number
    globalID:string
    workYear: string
    wpfsRequestStatus: string
    districtName: string
    regionName: string
    for_NO: string
    trtUnit: string
}