export class SpatialReference{
    wkId:number
    latestWkId:number
}