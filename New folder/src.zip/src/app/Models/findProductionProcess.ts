export class findProductionProcess{
    onatNetia:number;
    meshtala:number;
    status:number;
    sugTochnit:number;
}