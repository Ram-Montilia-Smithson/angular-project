

export class ContestDetailsModel {
    constructor(
        public title?: string,
        public data?: string | number
    ) { }
}