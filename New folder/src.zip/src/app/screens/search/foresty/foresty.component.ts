import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foresty',
  templateUrl: './foresty.component.html',
  styleUrls: ['./foresty.component.scss']
})
export class ForestyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
