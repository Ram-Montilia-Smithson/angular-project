import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bee-complete-header',
  templateUrl: './add-bee-complete-header.component.html',
  styleUrls: ['./add-bee-complete-header.component.scss']
})
export class AddBeeCompleteHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
