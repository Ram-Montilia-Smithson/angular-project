export class NewBeeCompleteTableModel{
    constructor(
        public id?:string|number,
        public tzemach?:string,
        public ashtaol?:string,
        public golani?:string,
        public gilat?:string,
        public kamut?:string,
        public misparTochnit?:number
    ){}
}