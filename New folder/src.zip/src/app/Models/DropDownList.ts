export class DropDownList{
    code:string;
    name:string;
}