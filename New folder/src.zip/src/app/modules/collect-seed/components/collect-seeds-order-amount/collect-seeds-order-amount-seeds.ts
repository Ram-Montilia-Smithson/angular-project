export class CollectSeedsOrderAmountSeedsModel{
    constructor(
        public id?:string|number,
        public fruitWeigh?:string|number,
        public seedWeigh?:string|number,
        public bagNumber?:string|number
    ){

    }
}