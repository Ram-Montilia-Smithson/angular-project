export class addProductionProcessBase{
    sugTochnit:number;
    onatNetia:number;
}