import { addProductionProcessBase } from "./addProductionProcessBase";
export class addProductionProcess extends addProductionProcessBase{
mishtala:number;
command:string;
}