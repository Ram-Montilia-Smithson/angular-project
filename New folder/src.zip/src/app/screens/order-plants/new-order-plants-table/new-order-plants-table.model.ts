export class NewOrderPlantsTableModel {
    constructor(
      public id?: number | string,
      public lakoach?: string,
      public phone?: string,
      public address?: string,
      public email?: string,
      public minHatzemach?: string,
      public kamut?: number | string,
      public ashtaol?: number | string,
      public golani?: number | string,
      public gilat?: number | string,
      
    ) {}
  }
