export class Yaarot{
    fid:number
    district_C:number
    region_Cod :number
    foR_Num:number
    foR_Name:string
}