import { Domain } from "./Domain"
export class Feild{
    name:string
    type:string
    alias:string
    sqlType:string
    domaines:Domain
    defaultValue:string
    length:number
}