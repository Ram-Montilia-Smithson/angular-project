import { addProductionProcessBase } from "./addProductionProcessBase";

export  class addProductionProcessWithExcel<T> extends addProductionProcessBase{
    ListOfExcelpage:T[];
}