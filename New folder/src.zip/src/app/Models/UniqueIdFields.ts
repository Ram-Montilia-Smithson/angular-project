export class UniqueIdFields{
    name:string;
    isSystemMaintained:boolean
}