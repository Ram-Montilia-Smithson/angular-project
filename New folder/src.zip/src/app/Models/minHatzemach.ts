export class minHatzemach{
    shemMinHatzemach:string;
    code:number
}