export  class status{
    statusCode:string
    statusName:string
}