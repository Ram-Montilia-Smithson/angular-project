export class tochnitYitzur{
     onatNetia:string
    sugTochnit:string
   mashtela:string
    status:string
    modifiedDate:string
     isShmita:boolean
    hearot:string
}