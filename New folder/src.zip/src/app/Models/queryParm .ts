export class queryParm {
    queryParm:string
}