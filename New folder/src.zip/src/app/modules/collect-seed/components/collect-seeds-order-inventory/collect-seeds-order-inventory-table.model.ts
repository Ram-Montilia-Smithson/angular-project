export class CollectSeedsOrderInventoryTableModel{
    constructor(
        public id?: string | number,
        public date?: string,
        public certificate?: number,
        public seedsAmount?: string,
     
    ) { }
}