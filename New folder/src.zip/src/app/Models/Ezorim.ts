export class Ezorim{
    merchav_co:number
    ezor_code:number
    ezor_name:string
}