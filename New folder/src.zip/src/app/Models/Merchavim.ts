export class Merchavim{
    objectid:number
    merchav_co:number
    merchav_na :string
}