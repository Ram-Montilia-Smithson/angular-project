import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'kkl-form-group',
  templateUrl: './form-group.component.html',
  styleUrls: ['./form-group.component.scss']
})
export class FormGroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
