export class BeeGrazing{
    codePlant:number;
    nameOfPlant:string;
    count:number;
}