export class CollectSeedsOrderLocationModel{
    constructor(
        public id:number|string,
        public siteSize:string,
        public treeNumber:string,
        public treeDirections:string
    ){

    }
}