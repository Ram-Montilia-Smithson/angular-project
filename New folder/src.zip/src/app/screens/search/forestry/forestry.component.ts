import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forestry',
  templateUrl: './forestry.component.html',
  styleUrls: ['./forestry.component.scss']
})
export class ForestryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
