export class NewOrderPlantsCompleteInnerTableModel{
    constructor(
        public id?: string | number,
        public mashtela?: string,
        public kamut?: number,
        public lakoach?: string,
        public phone?: string,
        public address?: string,
        public email?: string,
     
    ){}
}
