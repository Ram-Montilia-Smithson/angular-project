export class CollectSeedsOrderAmountCalcModel{
    constructor(
        public id:string|number,
        public seedWeigh:string|number,
        public seedCount:string|number,
        public seedsCountInPortion:string|number
    ){

    }
}