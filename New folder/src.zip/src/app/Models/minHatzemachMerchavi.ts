import { minHatzemach } from "./minHatzemach"

export class minHatzemachMerchavi {
     misparTochnit: number
     id: number
     kodMinHatzemach: number
     minHatzemach: string
     kamut: number
     ezor: number
     kibul: number
     ribuy: number
     makor: number
     hearot: string
}