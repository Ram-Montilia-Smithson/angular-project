export class Attributes{
    workYear:number
    trtUnit:string
    wpfsRequestStatus:string
    districtName:string
    regionName:string
    foR_Name:string
}