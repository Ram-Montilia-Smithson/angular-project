export class MireDvorim{
    codePlant:number=0;
    nameOfPlant:string;
    count:number;
}