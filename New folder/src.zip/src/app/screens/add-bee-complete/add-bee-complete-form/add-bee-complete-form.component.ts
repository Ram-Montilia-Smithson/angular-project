import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-bee-complete-form',
  templateUrl: './add-bee-complete-form.component.html',
  styleUrls: ['./add-bee-complete-form.component.scss']
})
export class AddBeeCompleteFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
