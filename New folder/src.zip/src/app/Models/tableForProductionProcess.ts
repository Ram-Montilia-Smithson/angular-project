export class tableForProductionProcess{
id: number
mashtela: string
modifiedDate: string | Date
onatNetia: {text:string,isShmita:boolean}
status: string
sugTochnit: string
}
