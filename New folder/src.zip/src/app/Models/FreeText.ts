export class FreeText{
    freeText:string
}