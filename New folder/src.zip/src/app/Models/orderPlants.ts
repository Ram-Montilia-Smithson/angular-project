export class orderPlants{
   public mineTzemach:any[]
    public  id :number
    public machtaniyim :number
    public  choreshTivi :number
    public  ekaliptus :number
    public  shitim :number
    public  atzeyNoy :number
    public  total :number
    public  onatNetia :number
    public  status :number
}