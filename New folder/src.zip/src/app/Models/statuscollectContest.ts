export class statuscollectContest{
    stStageStatus:string;
    stStageStatusName:string

}