import { AllSearchUnitsForWorkDilution } from '../Models/AllSearchUnitsForWorkDilution';

export  class ObjectForWorkUnit extends AllSearchUnitsForWorkDilution{
    foR_Name:string
}