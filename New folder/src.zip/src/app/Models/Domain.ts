import { DropDownList } from "./DropDownList"

export class Domain{
    type:string
    name:string
    codedValues:DropDownList[]
}